package com.schoolschedule.app.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.schoolschedule.app.data.AppPreferences
import com.schoolschedule.app.data.StorageRepository
import com.schoolschedule.app.domain.DataLoadResult
import com.schoolschedule.app.domain.DayStatus
import com.schoolschedule.app.domain.Lesson
import com.schoolschedule.app.domain.ScheduleData
import com.schoolschedule.app.domain.ScheduleEngine
import com.schoolschedule.app.domain.UserRole
import com.schoolschedule.app.domain.UserSelection
import com.schoolschedule.app.notifications.NotificationScheduler
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime

enum class Screen { HOME, TODAY, FULL, TEACHER_WEEK, SETTINGS }

class AppController(private val context: Context) {
    private val repository = StorageRepository(context)
    private val preferences = AppPreferences(context)
    var data by mutableStateOf<ScheduleData?>(null)
        private set
    var errors by mutableStateOf<List<String>>(emptyList())
        private set
    var selection by mutableStateOf(preferences.selection)
        private set
    var screen by mutableStateOf(Screen.HOME)
    var notifyStart by mutableStateOf(preferences.notifyStart)
    var notifyEnd by mutableStateOf(preferences.notifyEnd)
    var notifyBefore by mutableStateOf(preferences.notifyBefore)

    init { reload() }
    fun path() = repository.dataPath()
    fun reload() {
        val result: DataLoadResult = repository.load()
        data = result.data
        errors = result.errors
        if (data != null && selection != null) NotificationScheduler.reschedule(context)
    }
    fun restore() { errors = repository.restoreDefaults(); reload() }
    fun saveSelection(value: UserSelection) { preferences.selection = value; selection = value; screen = Screen.HOME; NotificationScheduler.reschedule(context) }
    fun clearSelection() { preferences.selection = null; selection = null; NotificationScheduler.cancelAll(context) }
    fun updateNotifications(start: Boolean = notifyStart, end: Boolean = notifyEnd, before: Boolean = notifyBefore) {
        notifyStart = start; notifyEnd = end; notifyBefore = before
        preferences.notifyStart = start; preferences.notifyEnd = end; preferences.notifyBefore = before
        NotificationScheduler.reschedule(context)
    }
}

@Composable
fun SchoolScheduleApp(controller: AppController) {
    MaterialTheme(colorScheme = androidx.compose.material3.lightColorScheme(
        primary = Color(0xFF215A8A), secondary = Color(0xFF3E7D6E), tertiary = Color(0xFF9A5C20), surface = Color(0xFFFAFBFF)
    )) {
        if (controller.data == null) DataProblemScreen(controller)
        else if (controller.selection == null) SetupScreen(controller)
        else MainNavigation(controller)
    }
}

@Composable
private fun DataProblemScreen(controller: AppController) = Scaffold(topBar = { TitleBar("دوامي المدرسي") }) { padding ->
    Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("تعذر تحميل بيانات الدوام", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        controller.errors.forEach { Text("• $it", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 4.dp)) }
        Spacer(Modifier.height(18.dp))
        Text("مسار الملفات: ${controller.path()}", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(18.dp))
        Button(onClick = controller::reload, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("إعادة تحميل ملفات البيانات") }
        OutlinedButton(onClick = controller::restore, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) { Text("استعادة البيانات الافتراضية") }
    }
}

@Composable
private fun SetupScreen(controller: AppController) {
    val engine = remember(controller.data) { ScheduleEngine(requireNotNull(controller.data)) }
    var role by remember { mutableStateOf<UserRole?>(null) }
    Scaffold(topBar = { TitleBar("إعداد الدوام") }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text(if (role == null) "مرحبًا، اختر نوع المستخدم" else if (role == UserRole.STUDENT) "اختر الصف" else "اختر المادة", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
            item { Text("سيتم حفظ اختيارك محليًا ويمكن تغييره لاحقًا من الإعدادات.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (role == null) {
                item { OptionCard("طالب", "لعرض جدول صفك فقط") { role = UserRole.STUDENT } }
                item { OptionCard("مدرس", "لعرض برنامج المادة التي تدرّسها") { role = UserRole.TEACHER } }
            } else {
                val values = if (role == UserRole.STUDENT) engine.grades() else engine.subjects()
                items(values) { value -> OptionCard(value, if (role == UserRole.STUDENT) "عرض جدول $value" else "برنامج مادة $value") { controller.saveSelection(UserSelection(requireNotNull(role), value)) } }
                item { TextButton(onClick = { role = null }) { Text("رجوع لاختيار النوع") } }
            }
        }
    }
}

@Composable
private fun MainNavigation(controller: AppController) {
    when (controller.screen) {
        Screen.HOME -> HomeScreen(controller)
        Screen.TODAY -> TableScreen(controller, todayOnly = true)
        Screen.FULL -> TableScreen(controller, todayOnly = false)
        Screen.TEACHER_WEEK -> TeacherWeeklyScreen(controller)
        Screen.SETTINGS -> SettingsScreen(controller)
    }
}

@Composable
private fun HomeScreen(controller: AppController) {
    val data = requireNotNull(controller.data); val selection = requireNotNull(controller.selection); val engine = remember(data) { ScheduleEngine(data) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }
    val status = engine.status(now, selection)
    Scaffold(topBar = { TitleBar("دوامي المدرسي", action = { IconButton(onClick = { controller.screen = Screen.SETTINGS }) { Icon(Icons.Default.Settings, "الإعدادات") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { HeaderDate(engine, now.toLocalDate(), selection) }
            item { CurrentStatusCard(status, selection.role == UserRole.TEACHER) }
            item { Button(onClick = { controller.screen = Screen.TODAY }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text("عرض جدول اليوم") } }
            item { OutlinedButton(onClick = { controller.screen = Screen.FULL }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text(if (selection.role == UserRole.TEACHER) "عرض كل الصفوف والمواد" else "عرض الجدول الكامل") } }
            if (selection.role == UserRole.TEACHER) {
                item { Button(onClick = { controller.screen = Screen.TEACHER_WEEK }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)) { Text("البرنامج الأسبوعي للمادة") } }
            }
            item { TextButton(onClick = { controller.screen = Screen.SETTINGS }, modifier = Modifier.fillMaxWidth()) { Text("الإعدادات") } }
        }
    }
}

@Composable
private fun HeaderDate(engine: ScheduleEngine, date: LocalDate, selection: UserSelection) = Column {
    Text("${engine.dayName(date)} ${arabicDate(date)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Text(if (selection.role == UserRole.STUDENT) "الصف: ${selection.value}" else "المادة: ${selection.value}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
}

@Composable
private fun CurrentStatusCard(status: DayStatus, teacher: Boolean) = Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when (status) {
            DayStatus.Holiday -> { Text("اليوم عطلة", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("الجمعة والسبت والعطل الاستثنائية لا تحتوي على حصص.") }
            DayStatus.Finished -> { Text("انتهى الدوام اليوم", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("يمكنك مراجعة جدول اليوم أو الجدول الكامل.") }
            is DayStatus.BeforeStart -> { Text("لم يبدأ الدوام بعد", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); NextLesson(status.next, status.next.period.start, status = null, teacher = teacher) }
            is DayStatus.Break -> { Text("استراحة", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); status.next?.let { NextLesson(it, it.period.start, status.remainingSeconds, teacher) } ?: Text("لا توجد حصة قادمة اليوم") }
            is DayStatus.InLesson -> {
                Text("الحصة الحالية", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                LessonDetails(status.current, teacher, prominent = true)
                Text("باقي ${formatDuration(status.remainingSeconds)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Divider(Modifier.padding(vertical = 4.dp))
                Text("الحصة القادمة", style = MaterialTheme.typography.labelLarge)
                status.next?.let { NextLesson(it, it.period.start, null, teacher) } ?: Text("لا توجد حصة قادمة اليوم")
            }
        }
    }
}

@Composable
private fun NextLesson(lesson: Lesson, starts: java.time.LocalTime, status: Long?, teacher: Boolean) {
    LessonDetails(lesson, teacher)
    Text("تبدأ ${starts}", fontWeight = FontWeight.Medium)
    if (status != null) Text("بعد ${formatDuration(status)}")
}

@Composable
private fun LessonDetails(lesson: Lesson, teacher: Boolean, prominent: Boolean = false) = Column {
    Text("الحصة ${lesson.period.id} — ${lesson.subject}", style = if (prominent) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    if (teacher) Text(lesson.grades.joinToString(" + "), color = MaterialTheme.colorScheme.onPrimaryContainer)
}

@Composable
private fun TableScreen(controller: AppController, todayOnly: Boolean) {
    val data = requireNotNull(controller.data); val selection = requireNotNull(controller.selection); val engine = remember(data) { ScheduleEngine(data) }
    val days = if (todayOnly) listOf(engine.dayName(LocalDate.now())) else listOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس")
    Scaffold(topBar = { BackBar(if (todayOnly) "جدول اليوم" else if (selection.role == UserRole.TEACHER) "البرنامج الكامل" else "الجدول الكامل") { controller.screen = Screen.HOME } }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (todayOnly && engine.isHoliday(LocalDate.now())) item { EmptyCard("اليوم عطلة") }
            else items(days) { day ->
                if (!todayOnly && selection.role == UserRole.TEACHER) PeriodGrid(day, engine.allLessonsByPeriod(day))
                else DayTable(day, engine.lessonsForDay(day, selection), selection.role == UserRole.TEACHER)
            }
        }
    }
}

@Composable
private fun TeacherWeeklyScreen(controller: AppController) {
    val data = requireNotNull(controller.data)
    val selection = requireNotNull(controller.selection)
    val engine = remember(data) { ScheduleEngine(data) }
    val days = listOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس")
    Scaffold(topBar = { BackBar("البرنامج الأسبوعي") { controller.screen = Screen.HOME } }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Text("برنامج مادة ${selection.value}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
            item { Text("الشعب مرتبة حسب اليوم ورقم الحصة", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(days) { day ->
                val lessons = engine.lessonsForDay(day, selection)
                TeacherDayCard(day, lessons)
            }
        }
    }
}

@Composable
private fun TeacherDayCard(day: String, lessons: List<Lesson>) = Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
    Column(Modifier.padding(16.dp)) {
        Text(day, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        if (lessons.isEmpty()) Text("لا توجد حصة للمادة")
        lessons.forEach { lesson ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = {}, label = { Text("${lesson.period.id}") })
                Spacer(Modifier.width(10.dp))
                Text(lesson.grades.joinToString(" + "), Modifier.weight(1f), fontWeight = FontWeight.Medium)
                Text("${lesson.period.start}–${lesson.period.end}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PeriodGrid(day: String, rows: List<Pair<com.schoolschedule.app.domain.Period, List<Lesson>>>) = Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
    Column(Modifier.padding(16.dp)) {
        Text(day, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        rows.forEach { (period, lessons) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.Top) {
                AssistChip(onClick = {}, label = { Text("${period.id}") })
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    if (lessons.isEmpty()) Text("لا توجد حصة", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else lessons.groupBy { it.subject }.forEach { (subject, subjectLessons) ->
                        Text(subject, fontWeight = FontWeight.Bold)
                        Text(subjectLessons.joinToString(" + ") { it.grades.first() }, style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text("${period.start}–${period.end}", style = MaterialTheme.typography.bodySmall)
            }
            if (period != rows.last().first) Divider()
        }
    }
}

@Composable
private fun DayTable(day: String, lessons: List<Lesson>, showGrades: Boolean) = Card(Modifier.fillMaxWidth()) {
    Column(Modifier.padding(16.dp)) {
        Text(day, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        if (lessons.isEmpty()) Text("لا توجد حصص مسجلة")
        lessons.forEachIndexed { i, lesson ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = {}, label = { Text("${lesson.period.id}") })
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(lesson.subject, fontWeight = FontWeight.Bold)
                    if (showGrades) Text(lesson.grades.joinToString(" + "), style = MaterialTheme.typography.bodySmall)
                }
                Text("${lesson.period.start}–${lesson.period.end}", style = MaterialTheme.typography.bodySmall)
            }
            if (i < lessons.lastIndex) Divider()
        }
    }
}

@Composable
private fun SettingsScreen(controller: AppController) = Scaffold(topBar = { BackBar("الإعدادات") { controller.screen = Screen.HOME } }) { padding ->
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("اختيار المستخدم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { SettingItem("تغيير نوع المستخدم أو الصف/المادة", "${controller.selection?.value.orEmpty()}") { controller.clearSelection() } }
        item { Text("الإشعارات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        item { ToggleItem("إشعار عند بداية الحصة", controller.notifyStart) { controller.updateNotifications(start = it) } }
        item { ToggleItem("إشعار عند نهاية الحصة", controller.notifyEnd) { controller.updateNotifications(end = it) } }
        item { ToggleItem("إشعار قبل الحصة بـ5 دقائق", controller.notifyBefore) { controller.updateNotifications(before = it) } }
        item { Text("البيانات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
        item { SettingItem("إعادة تحميل ملفات البيانات", "لتطبيق تغييرات JSON الخارجية") { controller.reload() } }
        item { SettingItem("استعادة البيانات الافتراضية", "يستبدل ملفات JSON الحالية") { controller.restore() } }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("مسار ملفات البيانات", fontWeight = FontWeight.Bold); Text(controller.path(), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
    }
}

@Composable
private fun SettingItem(title: String, subtitle: String, onClick: () -> Unit) = Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) { Column(Modifier.padding(16.dp)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, style = MaterialTheme.typography.bodySmall) } }
@Composable
private fun ToggleItem(title: String, checked: Boolean, onChange: (Boolean) -> Unit) = Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium); Switch(checked = checked, onCheckedChange = onChange) } }
@Composable
private fun OptionCard(title: String, subtitle: String, click: () -> Unit) = Card(Modifier.fillMaxWidth().clickable(onClick = click), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) { Column(Modifier.padding(18.dp)) { Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text(subtitle) } }
@Composable
private fun EmptyCard(text: String) = Card(Modifier.fillMaxWidth()) { Text(text, Modifier.padding(18.dp), style = MaterialTheme.typography.titleMedium) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TitleBar(title: String, action: @Composable (() -> Unit)? = null) = CenterAlignedTopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }, actions = { action?.invoke() }, colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = MaterialTheme.colorScheme.surface))
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BackBar(title: String, onBack: () -> Unit) = CenterAlignedTopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } })

private fun formatDuration(seconds: Long): String { val m = seconds / 60; val s = seconds % 60; return if (m > 0) "$m دقيقة${if (s > 0) " و$s ثانية" else ""}" else "$s ثانية" }
private fun arabicDate(date: LocalDate): String { val months = listOf("", "كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران", "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول"); return "${date.dayOfMonth} ${months[date.monthValue]}" }
